const cardapio = [
  { nome: "Hambúrguer", preco: 15.99, imagem: "hamburguer.jpg" },
  { nome: "Pizza", preco: 22.99, imagem: "pizza.jpg" },
  { nome: "Salada", preco: 12.99, imagem: "salada.jpg" },
  { nome: "Sopa", preco: 9.99, imagem: "sopa.jpg" },
  { nome: "Sobremesa", preco: 7.99, imagem: "sobremesa.jpg" }
];

function criarItemCardapio(item) {
  const li = document.createElement("li");
  li.className = "menu-item";

  const img = document.createElement("img");
  img.src = item.imagem;
  li.appendChild(img);

  const span = document.createElement("span");
  span.textContent = `${item.nome} - R$ ${item.preco.toFixed(2)}`;
  li.appendChild(span);

  const button = document.createElement("button");
  button.textContent = "+";
  button.addEventListener("click", function() {
    // Lógica para adicionar item ao carrinho
    console.log("Adicionar ao carrinho:", item.nome);
  });
  li.appendChild(button);

  return li;
}

function exibirCardapio() {
  const menuList = document.getElementById("menu-list");

  cardapio.forEach(item => {
    const li = criarItemCardapio(item);
    menuList.appendChild(li);
  });
}

exibirCardapio();
